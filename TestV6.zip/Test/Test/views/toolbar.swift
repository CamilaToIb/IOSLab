//
//  Icons Second.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 14/11/23.
//

import SwiftUI

struct Icons_Second: View {
    var body: some View {

        NavigationStack {

            VStack {
                Spacer()
                Rectangle()
                .foregroundColor(.clear)
                .frame(width: 315, height: 45)
                .background(.black)
                .cornerRadius(88)
                .padding(30)
        }
            .toolbar {
                    ToolbarItem(placement: .bottomBar) {
                            Button("Tap me"){}
                    }
                    ToolbarItem(placement: .bottomBar) {
                            Button("Hello"){}
                        }
                    ToolbarItem(placement: .bottomBar) {
                        Button("Hello"){}
                    }
                    ToolbarItem(placement: .bottomBar) {
                        Button("Hello"){}
                    }
                }
                .navigationBarTitleDisplayMode(.inline)
                .toolbarBackground(.hidden, for: .bottomBar)
                .toolbarBackground(.visible, for: .bottomBar)
            }
        }
   }

#Preview {
    Icons_Second()
}
