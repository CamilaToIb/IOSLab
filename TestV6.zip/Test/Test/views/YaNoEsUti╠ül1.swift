//
//  SwiftUIView.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 14/11/23.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        ZStack {
            VStack {
                Text("Crear cuenta")
                    .font(
                        Font.custom("Montserrat", size: 28)
                            .weight(.bold)
                    )
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                    .frame(width: 214, height: 26, alignment: .top)
                    .padding(80)
                    .frame(height: nil)
                
                Spacer().frame(minHeight: 30, maxHeight: 30)
                
                Spacer()
                
                HStack {
                    Spacer ()
                    HStack { NavigationLink(destination: CrearCuenta1().navigationBarBackButtonHidden(true)) {
                        Text("Continuar")
                            .font(Font.custom("Work Sans", size: 14))
                            .multilineTextAlignment(.trailing)
                            .foregroundColor(Color(red: 1, green: 0.73, blue: 0))
                            .frame(width: 74, height: 18, alignment: .topTrailing)
                        Image("FlechaContinuar")
                    }
                    .padding(.horizontal,40)
                    }
                }
            }
            VStack {
                Spacer().frame(minHeight: 60, maxHeight: 60)
                VStack {
                    NavigationLink(destination: Icons_Second().navigationBarBackButtonHidden(true)) { Image("Museo1")
                    }
                }
                Text("Quiero promover un evento")
                    .font(Font.custom("Work Sans", size: 16))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                    .frame(width: 256, height: 18, alignment: .top)
                    .padding(8)
                
                Spacer()
                    .frame(minHeight: 50, maxHeight: 50)
                
                Image("Visitante1")
                
                Text("Busco eventos artísticos")
                    .font(Font.custom("Work Sans", size: 16))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                    .frame(width: 202, height: 18, alignment: .top)
                    .padding(8)
                
                Spacer().frame(minHeight: 20, maxHeight: 20)
            }
        }    }
}
    
#Preview {
    SwiftUIView()
}
