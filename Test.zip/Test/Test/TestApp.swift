//
//  TestApp.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 10/10/23.
//

import SwiftUI

@main
struct TestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
