//
//  Event.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 22/11/23.
//

import Foundation
import SwiftUI

struct Event {
    
    var id: Int
    var name: String
    var ubication: String
    var avatar: Image
    var avatarGrande: Image
    var description : String
}
