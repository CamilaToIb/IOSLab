//
//  MisEventos.swift
//  Test
//
//  Created by Diego Garza on 25/11/23.
//

import SwiftUI

struct MisEventos: View {
    var body: some View {
        
            VStack(alignment:
            .leading, spacing: 20) {
            Text("Mis eventos")
            .padding()
            .background(Color.yellow)
            .font(.title)
            .bold()
            .position(CGPoint(x: 100.0, y: 30.0))
            .cornerRadius(10.0)

            Spacer()

            ZStack {
            Text("")
            .padding(.top, 15.0)
            .padding(.bottom, 70)
            .padding(.leading, 45.0)
            .padding(.trailing, 90.0)
            .background(Color.black)
            .cornerRadius(20.0)
            .position(x: -40.0, y: -400.0)
            .frame(width: 140, height: 110)
            Spacer()
            
                HStack {
            Text("OCTUBRE")
            .font(.title3)
            .lineLimit(1)
            .bold()
            .foregroundStyle(Color.white)
            .frame(width: 100.0)
            .position(x: 85, y: -315)
            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
            .dynamicTypeSize(/*@START_MENU_TOKEN@*/.medium/*@END_MENU_TOKEN@*/)

            Spacer()
                    
            Text("Pintores mexicanos")
            .font(.title3)
            .bold()
            .padding(.bottom, 75.0)
            .frame(width: 215.0, height: 95.0)
            .foregroundStyle(Color.white)
            .background(Color.gray)
            .position(x: 200, y: -277)
            .dynamicTypeSize(/*@START_MENU_TOKEN@*/.large/*@END_MENU_TOKEN@*/)
                    
            Spacer()
                    
        VStack {
            Text("Exposición que reune los trabajos destacados de diversos artistas mexicanos.")
            .font(.footnote)
            .multilineTextAlignment(/*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .frame(width: 200.0)
            .position(x: 150, y: -270)
            .foregroundColor(/*@START_MENU_TOKEN@*/.white/*@END_MENU_TOKEN@*/)
                    }
                    
            Spacer()
                    
            VStack{
            Text("10")
            .font(.title3)
            .fontWeight(.thin)
            .lineLimit(1)
            .frame(width: 55.0)
            .foregroundStyle(Color.white)
            .background(Color.black)
            .cornerRadius(5.0)
            .position(x: -85.0, y: -265.0)
            .dynamicTypeSize(/*@START_MENU_TOKEN@*/.accessibility5/*@END_MENU_TOKEN@*/)}
            
                    Spacer()
                    
                ZStack(content: {
                    Text("")
                    .padding(.top, 15.0)
                    .padding(.bottom, 70)
                    .padding(.leading, 45.0)
                    .padding(.trailing, 90.0)
                    .background(Color.black)
                    .cornerRadius(20.0)
                    .position(x: -150, y: -300.0)
                        .frame(width: 140, height: 110)
                    
                    Spacer()
                            
                    HStack{
                    Text("OCTUBRE")
                    .font(.title3)
                    .lineLimit(1)
                    .bold()
                    .foregroundStyle(Color.white)
                    .frame(width: 100.0)
                    .position(x: -135, y: -215)
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                    .dynamicTypeSize(/*@START_MENU_TOKEN@*/.medium/*@END_MENU_TOKEN@*/)
                                
                    Spacer()
                        
                    Text("Blanco y negro")
                    .font(.title3)
                    .bold()
                    .padding(.bottom, 75.0)
                    .frame(width: 215.0, height: 95.0)
                    .foregroundStyle(Color.white)
                    .background(Color.gray)
                    .position(x: 25, y: -178)
                    .dynamicTypeSize(/*@START_MENU_TOKEN@*/.large/*@END_MENU_TOKEN@*/)
                            
                    Spacer()
                            
                        VStack {
                    Text("Colección de obras artísticas que promueven el arte contemporáneo e invitan a la reflexión.")
                    .font(.footnote)
                    .multilineTextAlignment(/*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .frame(width: 200.0)
                    .position(x: 20, y: -170)
                    .foregroundColor(/*@START_MENU_TOKEN@*/.white/*@END_MENU_TOKEN@*/)
                            }
                            
                    Spacer()
                            
                    VStack{
                    Text("30")
                    .font(.title3)
                    .fontWeight(.thin)
                    .lineLimit(1)
                    .frame(width: 65.0)
                    .foregroundStyle(Color.white)
                    .background(Color.black)
                    .cornerRadius(5.0)
                    .position(x: -158, y: -165.0)
                .dynamicTypeSize(/*@START_MENU_TOKEN@*/.accessibility5/*@END_MENU_TOKEN@*/)}
                        
                    Spacer()
                        
                        ZStack{
                    Text("")
                    .padding(.top, 15.0)
                    .padding(.bottom, 70)
                    .padding(.leading, 45.0)
                    .padding(.trailing, 90.0)
                    .background(Color.black)
                    .cornerRadius(20.0)
                    .position(x: -170.0, y: -200.0)
                    .frame(width: 140, height: 110)
                            
                    Spacer()
                                
                            HStack{
                    Text("NOVIEMBRE")
                    .font(.title3)
                    lineLimit(1)
                    bold()
                    foregroundStyle(Color.white)
                    frame(width: 110.0)
                    position(x: -175, y: -115)
                    fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                    dynamicTypeSize(/*@START_MENU_TOKEN@*/.medium/*@END_MENU_TOKEN@*/)
                                            
                    Spacer()
                                    
                    Text("Sueños")
                    .font(.title3)
                    .bold()
                    .padding(.bottom, 75.0)
                    .frame(width: 215.0, height: 95.0)
                    .foregroundStyle(Color.white)
                    .background(Color.gray)
                    .position(x: 25, y: -178)
                    .dynamicTypeSize(/*@START_MENU_TOKEN@*/.large/*@END_MENU_TOKEN@*/)
                                        
                                Spacer()
                                    
                                    
                                }
                                
                            }
                        }
                    })

                    
            }
            }
            
        
            
        };
    }
}

#Preview {
    MisEventos()
}
