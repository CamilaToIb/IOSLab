//
//  PantallaInicioBlanco.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 01/11/23.
//

import SwiftUI

struct PantallaInicioBlanco: View {
    
    
    var body: some View {

        
        ZStack {
            
            PantallaDeInicio ()
            
            
            
            ScrollView {
                Spacer(minLength: 135)
                ZStack {
                        
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 390, height: 880)
                            .background(.white)
                            .cornerRadius(30)
                    
                    VStack {
                        
                        Text("Próximos eventos")
                            .font(
                                Font.custom("Montserrat", size: 14)
                                    .weight(.heavy)
                            )
                            .foregroundColor(.black)
                            .padding()
                        
                        ListView()
                        
                        Spacer ()
                            .frame(width: 0, height: 20)
                        
                    }.padding(5)
                    
                    Spacer ()
                        .frame(width: 0, height: 30)
            }
        }
        
        
        
        VStack {
            Spacer()
            ZStack {
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 315, height: 45)
                    .background(.black)
                    .cornerRadius(88)
                    .padding(30)
                
                HStack {
                    Spacer ()
                        .frame(width: 53, height: 0)
                    Image ("ToolSelect")
                    Spacer ()
                }
                HStack {
                    Spacer ()                        .frame(width: 85, height: 0)
                    Image ("Casa2")
                        .padding(5)
                    Spacer ()
                    Image ("Lupa1")                          .padding(5)
                    Spacer ()
                    NavigationLink(destination: PerfilUsuario().navigationBarBackButtonHidden(true)) {
                        Image ("Perfil1")                       .padding(5)
                    }
                    Spacer ()
                    
                    Image("Mas")                            .padding(5)
                    Spacer ()
                        .frame(width: 85, height: 0)
                }
            }
            Spacer ()
                .frame(width: 0, height: 15)
        }
    }
        }
    }


#Preview {
    PantallaInicioBlanco()
}
