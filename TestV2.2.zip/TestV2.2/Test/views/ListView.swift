//
//  ListView.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 22/11/23.
//

import SwiftUI

private let events = [Event(id: 1, name: "Marco 2", ubication: "Museo Marco, Monterrey, N.L.", avatar: Image("iconoMuseo"), avatarGrande: Image("iconoMuseoG"), description: "Gran apertura del nuevo museo: Marco 2. Lorem ipsum dolor sit amet consectetur adipiscing elit platea duis viverra fames facilisis, faucibus leo erat proin magna molestie penatibus vivamus curae consequat. Euismod vulputate aliquet porta risus lobortis curae erat taciti tellus, enim est felis class luctus sodales nascetur ut quam urna, nisl sociosqu morbi lacinia litora vitae velit iaculis. Vitae faucibus sem dapibus inceptos id parturient arcu, enim mi pulvinar nostra molestie lacinia dictumst accumsan, praesent quam per vel ornare duis."),
                      Event(id: 2, name: "Galería Pepe", ubication: "Museo Papalote, San Nícolas, N.L.", avatar: Image("IconoM2"),avatarGrande: Image("IconoM2G"),
                            description: "Gran reapertura. Lorem ipsum dolor sit amet consectetur adipiscing elit platea duis viverra fames facilisis, faucibus leo erat proin magna molestie penatibus vivamus curae consequat. Euismod vulputate aliquet porta risus lobortis curae erat taciti tellus, enim est felis class luctus sodales nascetur ut quam urna, nisl sociosqu morbi lacinia litora vitae velit iaculis. Vitae faucibus sem dapibus inceptos id parturient arcu, enim mi pulvinar nostra molestie lacinia dictumst accumsan, praesent quam per vel ornare duis."),
                      Event(id: 3, name: "Cafe Paco", ubication: "Taquería Paco, Escobedo, N.L.", avatar: Image("IconoM3"),avatarGrande: Image("IconoM3G"),
                            description: "Obras llegan este verano. Lorem ipsum dolor sit amet consectetur adipiscing elit platea duis viverra fames facilisis, faucibus leo erat proin magna molestie penatibus vivamus curae consequat. Euismod vulputate aliquet porta risus lobortis curae erat taciti tellus, enim est felis class luctus sodales nascetur ut quam urna, nisl sociosqu morbi lacinia litora vitae velit iaculis. Vitae faucibus sem dapibus inceptos id parturient arcu, enim mi pulvinar nostra molestie lacinia dictumst accumsan, praesent quam per vel ornare duis."),
                      Event(id: 4, name: "Doctores", ubication: "Museo Jack, Santa Catarina, N.L.", avatar: Image("IconoM5"),avatarGrande: Image("IconoM5G"),
                            description: "Historia de la medicina en Nuevo León. Lorem ipsum dolor sit amet consectetur adipiscing elit platea duis viverra fames facilisis, faucibus leo erat proin magna molestie penatibus vivamus curae consequat. Euismod vulputate aliquet porta risus lobortis curae erat taciti tellus, enim est felis class luctus sodales nascetur ut quam urna, nisl sociosqu morbi lacinia litora vitae velit iaculis. Vitae faucibus sem dapibus inceptos id parturient arcu, enim mi pulvinar nostra molestie lacinia dictumst accumsan, praesent quam per vel ornare duis."),
                      Event(id: 5, name: "Sueños", ubication: "Oxxo, Santa Catarina, N.L.", avatar: Image("IconoM4"),avatarGrande: Image("IconoM4G"),
                            description: "Exposición de los sueños perdidos por muchos de sus trabajadores. Lorem ipsum dolor sit amet consectetur adipiscing elit platea duis viverra fames facilisis, faucibus leo erat proin magna molestie penatibus vivamus curae consequat. Euismod vulputate aliquet porta risus lobortis curae erat taciti tellus, enim est felis class luctus sodales nascetur ut quam urna, nisl sociosqu morbi lacinia litora vitae velit iaculis. Vitae faucibus sem dapibus inceptos id parturient arcu, enim mi pulvinar nostra molestie lacinia dictumst accumsan, praesent quam per vel ornare duis."),]

struct ListView: View {
    var body: some View {
        NavigationView {
            List(events, id: \.id) { event in
                NavigationLink(destination: ListDetailView (event: event)) {
                    RowView(event: event)
                }
            }
        }
        }
}

#Preview {
    ListView()
}
