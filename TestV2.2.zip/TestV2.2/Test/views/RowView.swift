//
//  RowView.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 22/11/23.
//

import SwiftUI

struct RowView: View {
    
    var event: Event
        
        var body: some View {
            
            HStack {
                event.avatar

            
                VStack (alignment: .leading) {
                    Text(event.name) .font(Font.custom("Montserrat", size: 20))
                        .foregroundColor(Color(red: 0.05, green: 0.01, blue: 0.23))
                    
                    Text(event.ubication)
                        .font(Font.custom("Work sans", size: 16))
                            .foregroundColor(Color(red: 0.05, green: 0.01, blue: 0.23))
                }
        }
    }
}

#Preview {
    RowView(event:
                Event(id: 1, name: "Marco 2", ubication: "Museo Marco, MTY, N.L.", avatar: Image("iconoMuseo"),avatarGrande: Image("iconoMuseo2"),
                     description: "Hola mundo"))
}
