//
//  ListDetailView.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 22/11/23.
//

import SwiftUI

struct ListDetailView: View {
  
    var event: Event
    
    var body: some View {
        VStack {
        ZStack {
            Color.black
                .cornerRadius(30)
            
            VStack {
                Spacer ()
                    .frame(width: 0, height: 50)
                
                ScrollView(.horizontal) {
                    HStack {
                        Spacer()
                            .frame (width: 35)
                        
                        ZStack {
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 310, height: 310)
                                .background(.white)
                                .cornerRadius(5)
                            
                            event.avatarGrande
                        }
                        Spacer()
                            .frame (width: 15)
                        
                        ZStack {
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 310, height: 310)
                                .background(.white)
                                .cornerRadius(5)
                            Image ("Perro")
                        }
                        
                        Spacer()
                            .frame (width: 35)
                    }
                }
                
                Spacer ()
                    .frame(width: 0, height: 15)
                Text(event.name)
                    .font(
                        Font.custom("Montserrat", size: 28)
                            .weight(.bold))
                    .foregroundColor(.white)
                
                Spacer()
                    .frame(height: 4)
                
                Text(event.ubication)
                    .font(
                        Font.custom("Lora", size: 14)
                            )
                    .foregroundColor(.white)
                
                
                Spacer ()
                    .frame(width: 0, height: 15)
                
                VStack (alignment: .center) {

                    Text(event.description)
                        .font(
                            Font.custom("Work Sans", size: 17)
                        )
                        .foregroundColor(.white)
                        .frame(width: 300)
                    
                    Spacer ()
                        .frame(width: 0, height: 35)
                }
                
                Spacer ()
            }
        }
    }
}

    struct ListDetailView_Previews: PreviewProvider {static var previews: some View {
        ListDetailView (event:
                            Event(id: 1, name: "Marco 2", ubication: "Museo Marco, MTY, N.L.", avatar: Image("iconoMuseo"), avatarGrande: Image("iconoMuseo2"),
                                  description: "Hola mundo"))
    }
    }
}

