//
//  PerfilUsuario.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 07/11/23.
//

import SwiftUI

struct PerfilUsuario: View {
    var body: some View {
        
        ZStack {
            VStack {
                HStack {
                    Image("Flecha3")
                    Text("Mi cuenta")
                        .font(
                            Font.custom("Montserrat", size: 14)
                                .weight(.heavy)
                        )
                        .foregroundColor(.black)
                        .background(Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 93, height: 25)
                            .background(Color(red: 1, green: 0.73, blue: 0))
                            .cornerRadius(24)
                            .overlay(
                                RoundedRectangle(cornerRadius: 24)
                                    .inset(by: 0.5)
                                    .stroke(Color(red: 1, green: 0.73, blue: 0), lineWidth: 1)
                            ))
                    Spacer()
                }
                .padding(.horizontal,38)
                
                Spacer()
                Rectangle()
                .foregroundColor(.clear)
                .frame(width: 315, height: 45)
                .background(.black)
                .cornerRadius(88)
                .padding(30)
            }
            
            VStack {
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(width: 126, height: 126)
                    .background(Color(red: 0.16, green: 0.16, blue: 0.16))
                    .cornerRadius(63)
                    .padding(50)
                Spacer ()
            }
        }
    }
}

#Preview {
    PerfilUsuario()
}
