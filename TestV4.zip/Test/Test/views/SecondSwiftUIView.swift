//
//  SecondSwiftUIView.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 24/10/23.
//

import SwiftUI

struct SecondSwiftUIView: View {
    var body: some View {
        ZStack {
        Color.black.edgesIgnoringSafeArea(.all)
           
            VStack {
            
                ZStack {
                    
                    VStack {
                        HStack {
                            NavigationLink(destination: ContentView().navigationBarBackButtonHidden(true)) {
                                Image("Regresar1")
                                    .padding(.horizontal,38)
                            }
                            Spacer()
                        }
                        Spacer()
                    }
                    
                    VStack {
                        Text("Crear cuenta")
                            .font(
                                Font.custom("Montserrat", size: 28)
                                    .weight(.bold)
                            )
                            .multilineTextAlignment(.center)
                            .foregroundColor(.white)
                            .frame(width: 214, height: 26, alignment: .top)
                            .padding(80)
                            .frame(height: nil)
                        
                        Spacer().frame(minHeight: 30, maxHeight: 30)
                        
                        Spacer()
                        
                        HStack {
                            Spacer ()
                            HStack { NavigationLink(destination: CrearCuenta1().navigationBarBackButtonHidden(true)) {
                                Text("Continuar")
                                    .font(Font.custom("Work Sans", size: 14))
                                    .multilineTextAlignment(.trailing)
                                    .foregroundColor(Color(red: 1, green: 0.73, blue: 0))
                                    .frame(width: 74, height: 18, alignment: .topTrailing)
                                Image("FlechaContinuar")
                            }
                            .padding(.horizontal,40)
                            }
                        }
                    }
                    VStack {
                        Spacer().frame(minHeight: 60, maxHeight: 60)
                    Image("Museo1")
                    Text("Quiero promover un evento")
                        .font(Font.custom("Work Sans", size: 16))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                    
                        .frame(width: 256, height: 18, alignment: .top)
                        .padding(8)
                    Spacer()
                        .frame(minHeight: 50, maxHeight: 50)
                    
                    Image("Visitante1")
                    
                    Text("Busco eventos artísticos")
                        .font(Font.custom("Work Sans", size: 16))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .frame(width: 202, height: 18, alignment: .top)
                        .padding(8)
                    
                    Spacer().frame(minHeight: 20, maxHeight: 20)
                }
            }
            }
            }
        }
    }



#Preview {
    SecondSwiftUIView()
}
