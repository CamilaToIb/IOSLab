//
//  ContentView.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 10/10/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        Text("Iniciar sesión")
          .font(
            Font.custom("Montserrat", size: 28)
                .weight(.bold)
          )
          .multilineTextAlignment(.center)
          .foregroundColor(.black)
          .frame(width: 214, height: 26, alignment: .top)
        .padding(60)
        .frame(height: nil)
        
        Spacer()

        VStack {
            Text("Nombre de usuario")
              .font(Font.custom("Work Sans", size: 14))
              .foregroundColor(Color(red: 0.75, green: 0.75, blue: 0.75))
              .frame(width: 202, height: 18, alignment: .topLeading)
              .background(Rectangle()
                .foregroundColor(.clear)
                .frame(width: 331, height: 47)
                .background(Color(red: 0.93, green: 0.93, blue: 0.93))
                .cornerRadius(20))
              .padding(15)
            
            Text("Contraseña")
              .font(Font.custom("Work Sans", size: 14))
              .foregroundColor(Color(red: 0.75, green: 0.75, blue: 0.75))
              .frame(width: 180, height: 17, alignment: .topLeading)
              .background(Rectangle()
                .foregroundColor(.clear)
                .frame(width: 331, height: 47)
                .background(Color(red: 0.93, green: 0.93, blue: 0.93))
                .cornerRadius(20))
              .padding(15)
            
            Text("¿Olvidaste tu crontaseña?")
                .font(Font.custom("Montserrat", size: 12))
                .multilineTextAlignment(.trailing)
                .foregroundColor(.black)
                .frame(width: 179, height: 18, alignment: .topTrailing)
        }
        
        Text("Iniciar sesión")
          .font(Font.custom("Montserrat", size: 16))
          .multilineTextAlignment(.center)
          .foregroundColor(.white)
          .frame(width: 180, height: 22, alignment: .top)
          .background(Rectangle()
            .foregroundColor(.clear)
            .frame(width: 206, height: 53)
            .background(.black)
            .cornerRadius(31.5))
          .padding(20.0)
        
        
        Spacer()
        Spacer()

        
        
        Text("¿Aún no tienes una cuenta? ¡Regístrate!")
          .font(Font.custom("Montserrat", size: 14))
          .multilineTextAlignment(.center)
          .foregroundColor(Color(red: 0.05, green: 0.01, blue: 0.23))
          .frame(width: 331, height: 18, alignment: .top)
          .background(Rectangle()
            .foregroundColor(.clear)
            .frame(width: 390, height: 80)
            .background(Color(red: 1, green: 0.73, blue: 0)))
    }
}

#Preview {
    ContentView()
}

