//
//  ListView.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 22/11/23.
//

import SwiftUI

private let events = [Event(id: 1, name: "Marco 2", ubication: "Museo Marco, Monterrey, N.L.", avatar: Image("IconoUsuario")),
                      Event(id: 2, name: "Galería", ubication: "Museo Papalote, San Nícolas, N.L.", avatar: Image("IconoUsuario")),
                      Event(id: 3, name: "Cafe Paco", ubication: "Taquería Paco, Escobedo, N.L.", avatar: Image("IconoUsuario")),
                      Event(id: 4, name: "Doctor", ubication: "Museo Jack, Santa Catarina, N.L.", avatar: Image("IconoUsuario")),]

struct ListView: View {
    var body: some View {
        NavigationView {
            List(events, id: \.id) { event in
                NavigationLink(destination: ListDetailView (event: event).navigationBarBackButtonHidden(true)) {
                    RowView(event: event)
                }
            }
        }
        }
}

#Preview {
    ListView()
}
