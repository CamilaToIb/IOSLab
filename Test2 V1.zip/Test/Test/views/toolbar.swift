//
//  Icons Second.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 14/11/23.
//

import SwiftUI

struct Icons_Second: View {
    var body: some View {

        ZStack {
            PantallaDeInicio()
            
            ScrollView {
                Spacer(minLength: 135)
                ZStack {
                    VStack {
                        
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 390, height: 1080)
                            .background(.white)
                            .cornerRadius(30)
                    }
                    
                    VStack {
                        Text("Eventos abiertos")
                            .font(
                                Font.custom("Montserrat", size: 14)
                                    .weight(.heavy)
                            )
                            .foregroundColor(.black)
                        
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 326, height: 130)
                            .background(.gray)
                            .cornerRadius(20)
                            .padding(14)
                        
                        Text("Próximos eventos")
                            .font(
                                Font.custom("Montserrat", size: 14)
                                    .weight(.heavy)
                            )
                            .foregroundColor(.black)
                        
                        HStack {
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 150, height: 160)
                                .background(.gray)
                                .cornerRadius(20)
                                .padding(9)
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 150, height: 160)
                                .background(.gray)
                                .cornerRadius(20)
                                .padding(9)
                        }.padding(5)
                        HStack {
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 150, height: 160)
                                .background(.gray)
                                .cornerRadius(20)
                                .padding(9)
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 150, height: 160)
                                .background(.gray)
                                .cornerRadius(20)
                                .padding(9)
                        }.padding(5)
                        HStack {
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 150, height: 160)
                                .background(.gray)
                                .cornerRadius(20)
                                .padding(9)
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 150, height: 160)
                                .background(.gray)
                                .cornerRadius(20)
                                .padding(9)
                        }.padding(5)
                        HStack {
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 150, height: 160)
                                .background(.gray)
                                .cornerRadius(20)
                                .padding(9)
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 150, height: 160)
                                .background(.gray)
                                .cornerRadius(20)
                                .padding(9)
                        }.padding(5)
                        Spacer ()
                            .frame(width: 0, height: 30)
                    }
                    //ListView()
                }
            }
        }
        }
   }

#Preview {
    Icons_Second()
}
