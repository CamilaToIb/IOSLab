//
//  RowView.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 22/11/23.
//

import SwiftUI

struct RowView: View {
    
    var event: Event
        
        var body: some View {
            VStack {
                event.avatar
                Text(event.name)
                Text(event.ubication)
        }
    }
}

#Preview {
    RowView(event:
                Event(id: 1, name: "Marco 2", ubication: "Museo Marco, MTY, N.L.", avatar: Image("IconoUsuario")))
}
