//
//  TestApp.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 10/10/23.
//

import SwiftUI
import Firebase

@main
struct TestApp: App {
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
