//
//  Icons Second.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 14/11/23.
//

import SwiftUI

struct Icons_Second: View {
    var body: some View {
        NavigationLink(destination: Icons_Second().navigationBarBackButtonHidden(true)) { Image("Museo1")
        }            }
   }

#Preview {
    Icons_Second()
}
