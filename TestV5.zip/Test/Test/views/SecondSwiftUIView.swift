//
//  SecondSwiftUIView.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 24/10/23.
//

import SwiftUI

struct SecondSwiftUIView: View {
    @State private var museoSelect = false
    @State private var visitanteSelect = false
    
    var body: some View {
        NavigationView {
        ZStack {
        Color.black.edgesIgnoringSafeArea(.all)
           
            VStack {
            
                ZStack {
                    
                    VStack {
                        HStack {
                            NavigationLink(destination: ContentView().navigationBarBackButtonHidden(true)) {
                                Image("Regresar1")
                                    .padding(.horizontal,38)
                            }
                            Spacer()
                        }
                        Spacer()
                    }
                    VStack {
                        ZStack {
                            VStack {
                                Text("Crear cuenta")
                                    .font(
                                        Font.custom("Montserrat", size: 28)
                                            .weight(.bold)
                                    )
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(.white)
                                    .frame(width: 214, height: 26, alignment: .top)
                                    .padding(80)
                                    .frame(height: nil)
                                
                                Spacer().frame(minHeight: 30, maxHeight: 30)
                                
                                Spacer()
                                
                                ZStack {
                                    if museoSelect {
                                        HStack {
                                            Spacer ()
                                            HStack { NavigationLink(destination: CrearCuenta2().navigationBarBackButtonHidden(true)) {
                                                Text("Continuar")
                                                    .font(Font.custom("Work Sans", size: 14))
                                                    .multilineTextAlignment(.trailing)
                                                    .foregroundColor(Color(red: 1, green: 0.73, blue: 0))
                                                    .frame(width: 74, height: 18, alignment: .topTrailing)
                                                Image("FlechaContinuar")
                                            }
                                            .padding(.horizontal,40)
                                            }
                                        }
                                    }
                                    if visitanteSelect {
                                        HStack {
                                            Spacer ()
                                            HStack { NavigationLink(destination: CrearCuenta1().navigationBarBackButtonHidden(true)) {
                                                Text("Continuar")
                                                    .font(Font.custom("Work Sans", size: 14))
                                                    .multilineTextAlignment(.trailing)
                                                    .foregroundColor(Color(red: 1, green: 0.73, blue: 0))
                                                    .frame(width: 74, height: 18, alignment: .topTrailing)
                                                Image("FlechaContinuar")
                                            }
                                            .padding(.horizontal,40)
                                            }
                                        }
                                    }
                                }
                            }
                            VStack {
                                Spacer().frame(minHeight: 60, maxHeight: 60)
                                VStack {
                                    Button(action:
                                            {museoSelect.toggle()
                                        visitanteSelect = false
                                    }, label:
                                            {Image ("Museo1")}
                                    )}
                                
                                Text("Quiero promover un evento")
                                    .font(Font.custom("Work Sans", size: 16))
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(.white)
                                    .frame(width: 256, height: 18, alignment: .top)
                                    .padding(8)
                                
                                Spacer()
                                    .frame(minHeight: 50, maxHeight: 50)
                                
                                VStack {Button(action:
                                        {visitanteSelect.toggle()
                                    museoSelect = false
                                }, label:
                                        {Image ("Visitante1")}
                                )}
                                
                                Text("Busco eventos artísticos")
                                    .font(Font.custom("Work Sans", size: 16))
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(.white)
                                    .frame(width: 202, height: 18, alignment: .top)
                                    .padding(8)
                                
                                Spacer().frame(minHeight: 20, maxHeight: 20)
                            }
                            
                                VStack {
                                    Spacer().frame(minHeight: 60, maxHeight: 60)
                                    VStack {
                                        if museoSelect {
                                        Image ("Museo2").transition(.opacity)
                                    }
                                    }
                                    Spacer()
                                        .frame(minHeight: 93, maxHeight: 93)
                                    Spacer().frame(minHeight: 241, maxHeight: 241)
                            }
                            
                            
                                VStack {
                                    Spacer().frame(minHeight: 60, maxHeight: 60)
                                        Spacer().frame(minHeight: 241, maxHeight: 241)
                                    if visitanteSelect{
                                        Image ("Visitante2").transition(.opacity)
                                    }
                                    Spacer().frame(minHeight: 31, maxHeight: 31)
                            }
                        }
                    }
                }
            }
            }
            }
        }
    }



#Preview {
    SecondSwiftUIView()
}
