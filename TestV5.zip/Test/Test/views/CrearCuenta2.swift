//
//  CrearCuenta2.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 14/11/23.
//

import SwiftUI

struct CrearCuenta2: View {
    var body: some View {
        VStack {
        
            ZStack {
            
        VStack {
            HStack {
                NavigationLink(destination: SecondSwiftUIView().navigationBarBackButtonHidden(true)) {
                    Image("Flecha2")
                        .padding(.horizontal,38)
                }
                Spacer()
            }
            Spacer()
        }
                
                VStack {
    Text("Crear cuenta2")
      .font(
        Font.custom("Montserrat", size: 28)
            .weight(.bold)
      )
      .multilineTextAlignment(.center)
      .foregroundColor(.black)
      .frame(width: 214, height: 26, alignment: .top)
    .padding(80)
    .frame(height: nil)
    
    Spacer().frame(minHeight: 30, maxHeight: 30)

                    
    VStack {
        Text("Correo electrónico")
          .foregroundColor(Color(red: 0.75, green: 0.75, blue: 0.75))
          .frame(width: 202, height: 18, alignment: .topLeading)
          .background(Rectangle()
            .foregroundColor(.clear)
            .frame(width: 331, height: 47)
            .background(Color(red: 0.93, green: 0.93, blue: 0.93))
            .cornerRadius(20))
          .padding(18)
        
        Text("Conraseña")
          .font(Font.custom("Work Sans", size: 14))
          .foregroundColor(Color(red: 0.75, green: 0.75, blue: 0.75))
          .frame(width: 202, height: 18, alignment: .topLeading)
          .background(Rectangle()
            .foregroundColor(.clear)
            .frame(width: 331, height: 47)
            .background(Color(red: 0.93, green: 0.93, blue: 0.93))
            .cornerRadius(20))
          .padding(18)
        
        Text("Nombre de usuario")
          .font(Font.custom("Work Sans", size: 14))
          .foregroundColor(Color(red: 0.75, green: 0.75, blue: 0.75))
          .frame(width: 180, height: 17, alignment: .topLeading)
          .background(Rectangle()
            .foregroundColor(.clear)
            .frame(width: 331, height: 47)
            .background(Color(red: 0.93, green: 0.93, blue: 0.93))
            .cornerRadius(20))
          .padding(18)
    }
                    NavigationLink(destination: PantallaInicioBlanco().navigationBarBackButtonHidden(true)) {
                        Text("Registrarse")
                            .font(Font.custom("Montserrat", size: 16))
                            .multilineTextAlignment(.center)
                            .foregroundColor(.white)
                            .frame(width: 180, height: 22, alignment: .top)
                            .background(Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 206, height: 53)
                                .background(.black)
                                .cornerRadius(31.5))
                    }
                    .padding(76.0)
    Spacer()
    Spacer()
    
                }
}
        }
    }
}


#Preview {
    CrearCuenta2()
}
