//
//  PantallaInicioBlanco.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 01/11/23.
//

import SwiftUI

struct PantallaInicioBlanco: View {
    var body: some View {
        
        ZStack {
            PantallaDeInicio ()
        ScrollView {
           
            Spacer(minLength: 135)
            ZStack {
                VStack {
                    
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 390, height: 1040)
                        .background(.white)
                        .cornerRadius(30)
                }
                
                VStack {
                    Text("Eventos abiertos")
                      .font(
                        Font.custom("Montserrat", size: 14)
                          .weight(.heavy)
                      )
                      .foregroundColor(.black)
                    
                    Rectangle()
                      .foregroundColor(.clear)
                      .frame(width: 326, height: 130)
                      .background(.black)
                      .cornerRadius(20)
                      .padding(14)
                    
                Text("Próximos eventos")
                  .font(
                    Font.custom("Montserrat", size: 14)
                      .weight(.heavy)
                  )
                  .foregroundColor(.black)
                    
                    HStack {
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 150, height: 160)
                            .background(.black)
                            .cornerRadius(20)
                            .padding(9)
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 150, height: 160)
                            .background(.black)
                            .cornerRadius(20)
                            .padding(9)
                    }.padding(5)
                        HStack {
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 150, height: 160)
                                .background(.black)
                                .cornerRadius(20)
                                .padding(9)
                            Rectangle()
                                .foregroundColor(.clear)
                                .frame(width: 150, height: 160)
                                .background(.black)
                                .cornerRadius(20)
                                .padding(9)
                        }.padding(5)
                    HStack {
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 150, height: 160)
                            .background(.black)
                            .cornerRadius(20)
                            .padding(9)
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 150, height: 160)
                            .background(.black)
                            .cornerRadius(20)
                            .padding(9)
                    }.padding(5)
                    HStack {
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 150, height: 160)
                            .background(.black)
                            .cornerRadius(20)
                            .padding(9)
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 150, height: 160)
                            .background(.black)
                            .cornerRadius(20)
                            .padding(9)
                    }.padding(5)
                }
            }
                VStack{
                    
                }
        }
            VStack {
                Spacer()
                Rectangle()
                .foregroundColor(.clear)
                .frame(width: 315, height: 45)
                .background(.black)
                .cornerRadius(88)
                .padding(30)
        }
        }
    }
}

#Preview {
    PantallaInicioBlanco()
}
