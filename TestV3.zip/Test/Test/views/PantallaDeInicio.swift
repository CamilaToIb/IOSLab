//
//  PantallaDeInicio.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 01/11/23.
//

import SwiftUI

struct PantallaDeInicio: View {
    var body: some View {
        ZStack {
        Color.black.edgesIgnoringSafeArea(.all)
           
            VStack {
            
                ZStack {
                
                    VStack {
                        Image("Background1").resizable().scaledToFill()
                }
            
                    VStack {
                        HStack {
                            Text("Buscar eventos                    ")
                                .font(Font.custom("Work Sans", size: 12))
                                .foregroundColor(Color(red: 0.75, green: 0.75, blue: 0.75))
                            
                                .background(Rectangle()
                                    .foregroundColor(.clear)
                                    .frame(width: 260, height: 30)
                                    .background(Color(red: 0.95, green: 0.94, blue: 0.94))
                                    .cornerRadius(20)
                                ).padding(55)
                        
                        }
                        
                Spacer()
                }
            }
            }
            }
        }
}

#Preview {
    PantallaDeInicio()
}
