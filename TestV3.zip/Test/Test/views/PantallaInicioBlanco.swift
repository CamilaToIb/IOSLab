//
//  PantallaInicioBlanco.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 01/11/23.
//

import SwiftUI

struct PantallaInicioBlanco: View {
    var body: some View {
        
        ZStack {
            PantallaDeInicio ()
        ScrollView {
           
            Spacer(minLength: 135)
            ZStack {
                VStack {
                    
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 390, height: 1000)
                        .background(.white)
                        .cornerRadius(30)
                   
                    Text("Eventos abiertos")
                      .font(
                        Font.custom("Montserrat", size: 14)
                          .weight(.heavy)
                      )
                      .foregroundColor(.black)
                    
                }
                }
        }
        }
    }
}

#Preview {
    PantallaInicioBlanco()
}
