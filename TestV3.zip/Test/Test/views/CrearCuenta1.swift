//
//  CrearCuenta1.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 01/11/23.
//

import SwiftUI

struct CrearCuenta1: View {
    var body: some View {
        
            VStack {
            
                ZStack {
                
            VStack {
                HStack {
                    Spacer()
                Image("Regresar1")
                    Spacer()
                    Spacer()
                }
            }
                    
                    VStack {
        Text("Crear cuenta")
          .font(
            Font.custom("Montserrat", size: 28)
                .weight(.bold)
          )
          .multilineTextAlignment(.center)
          .foregroundColor(.black)
          .frame(width: 214, height: 26, alignment: .top)
        .padding(60)
        .frame(height: nil)
        
        Spacer()

        VStack {
            Text("Correo electrónico")
              .font(Font.custom("Work Sans", size: 14))
              .foregroundColor(Color(red: 0.75, green: 0.75, blue: 0.75))
              .frame(width: 202, height: 18, alignment: .topLeading)
              .background(Rectangle()
                .foregroundColor(.clear)
                .frame(width: 331, height: 47)
                .background(Color(red: 0.93, green: 0.93, blue: 0.93))
                .cornerRadius(20))
              .padding(15)
            
            Text("Conraseña")
              .font(Font.custom("Work Sans", size: 14))
              .foregroundColor(Color(red: 0.75, green: 0.75, blue: 0.75))
              .frame(width: 202, height: 18, alignment: .topLeading)
              .background(Rectangle()
                .foregroundColor(.clear)
                .frame(width: 331, height: 47)
                .background(Color(red: 0.93, green: 0.93, blue: 0.93))
                .cornerRadius(20))
              .padding(15)
            
            Text("Nombre de usuario")
              .font(Font.custom("Work Sans", size: 14))
              .foregroundColor(Color(red: 0.75, green: 0.75, blue: 0.75))
              .frame(width: 180, height: 17, alignment: .topLeading)
              .background(Rectangle()
                .foregroundColor(.clear)
                .frame(width: 331, height: 47)
                .background(Color(red: 0.93, green: 0.93, blue: 0.93))
                .cornerRadius(20))
              .padding(15)
            
            
        }
        
        Text("Iniciar sesión")
          .font(Font.custom("Montserrat", size: 16))
          .multilineTextAlignment(.center)
          .foregroundColor(.white)
          .frame(width: 180, height: 22, alignment: .top)
          .background(Rectangle()
            .foregroundColor(.clear)
            .frame(width: 206, height: 53)
            .background(.black)
            .cornerRadius(31.5))
          .padding(20.0)
        
        Spacer()
        Spacer()
        
                    }
    }
            }
        }
}

#Preview {
    CrearCuenta1()
}
