//
//  PerfilUsuario.swift
//  Test
//
//  Created by Jesús Efrén González Vázquez on 07/11/23.
//

import SwiftUI

struct PerfilUsuario: View {
    var body: some View {
        
        ZStack {
            VStack {
                HStack {
                    NavigationLink(destination: PantallaInicioBlanco().navigationBarBackButtonHidden(true))
                    {Image("Flecha3")
                    Text("Mi cuenta")
                        .font(
                            Font.custom("Montserrat", size: 14)
                                .weight(.heavy)
                        )
                        .foregroundColor(.black)
                        .background(Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 93, height: 25)
                            .background(Color(red: 1, green: 0.73, blue: 0))
                            .cornerRadius(24)
                            .overlay(
                                RoundedRectangle(cornerRadius: 24)
                                    .inset(by: 0.5)
                                    .stroke(Color(red: 1, green: 0.73, blue: 0), lineWidth: 1)
                            ))}
                    Spacer()
                }
                .padding(.horizontal,38)
                
                Spacer()
                VStack {
                    Spacer()
                    ZStack {
                        Rectangle()
                            .foregroundColor(.clear)
                            .frame(width: 315, height: 45)
                            .background(.black)
                            .cornerRadius(88)
                            .padding(30)
                        
                        HStack {
                            Spacer ()
                            Image ("ToolSelect")
                            Spacer ()
                                .frame(width: 120, height: 0)
                        }
                        HStack {
                           Spacer ()                        .frame(width: 85, height: 0)
                            NavigationLink(destination: PantallaInicioBlanco().navigationBarBackButtonHidden(true)) {
                                Image ("Casa1")
                                    .padding(5)
                            }
                            Spacer ()
                            Image ("Lupa1")                          .padding(5)
                            Spacer ()
                            Image ("Perfil2")                       .padding(5)
                            Spacer ()

                            Image("Mas")                            .padding(5)
                            Spacer ()
                                .frame(width: 85, height: 0)
                        }
                    }
                    }                    
                .ignoresSafeArea()
            }
            
            VStack {
                Spacer ()
                    .frame(width: 0, height: 50)
                
                ZStack {
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 126, height: 126)
                        .background(Color(red: 0.16, green: 0.16, blue: 0.16))
                        .cornerRadius(63)
                    Image ("IconoUsuario")
                }
                
                Spacer ()
                    .frame(width: 0, height: 30)
                Text("Nombre")
                    .font(
                        Font.custom("Montserrat", size: 16)
                            .weight(.bold))
                    .foregroundColor(.black)
                Spacer ()
                    .frame(width: 0, height: 45)
                
                ZStack {
                    (Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 319, height: 51)
                        .background(Color(red: 0.16, green: 0.16, blue: 0.16))
                        .cornerRadius(12))
                    HStack {
                        Spacer ().frame(width: 60, height: 0)
                        Text("Editar icono  ")
                        .font(
                            Font.custom("Montserrat", size: 12)
                                .weight(.heavy))
                        .foregroundColor(.white)
                        Spacer ()
                        Image ("Perfil1")
                        Spacer ().frame(width: 65, height: 0)
                }}
                
                Spacer ()
                    .frame(width: 0, height: 15)
                
                ZStack {
                    (Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 319, height: 51)
                        .background(Color(red: 0.16, green: 0.16, blue: 0.16))
                        .cornerRadius(12))
                    HStack {
                        Spacer ().frame(width: 60, height: 0)
                        Text("Editar icono  ")
                        .font(
                            Font.custom("Montserrat", size: 12)
                                .weight(.heavy))
                        .foregroundColor(.white)
                        Spacer ()
                        Image ("Editar")
                        Spacer ().frame(width: 65, height: 0)
                }}
                
                Spacer ()
                    .frame(width: 0, height: 15)
                
                ZStack {
                    (Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 319, height: 51)
                        .background(Color(red: 0.16, green: 0.16, blue: 0.16))
                        .cornerRadius(12))
                    HStack {
                        Spacer ().frame(width: 60, height: 0)
                        Text("Editar icono  ")
                        .font(
                            Font.custom("Montserrat", size: 12)
                                .weight(.heavy))
                        .foregroundColor(.white)
                        Spacer ()
                        Image ("Guardado1")
                        Spacer ().frame(width: 65, height: 0)
                }}
                
                Spacer ()
            }
        }
    }
}

#Preview {
    PerfilUsuario()
}
